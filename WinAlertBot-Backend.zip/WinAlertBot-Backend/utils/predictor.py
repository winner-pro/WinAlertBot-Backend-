# IA de prédiction
def predict():
    return 'WIN'