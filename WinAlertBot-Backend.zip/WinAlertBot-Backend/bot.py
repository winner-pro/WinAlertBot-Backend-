# Script principal du bot Telegram

if __name__ == '__main__':
    print('Bot démarré.')
