# Configuration
TOKEN = 'your-telegram-bot-token'
DB_PATH = 'predictions.db'
